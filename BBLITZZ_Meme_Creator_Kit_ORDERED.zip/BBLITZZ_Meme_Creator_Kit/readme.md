# BBLITZZ Meme Creator Kit
How to use:
1) Open a template in /templates.
2) Drop a background from /elements/backgrounds.
3) Add Lil Blitz PNGs from /elements/lilblitz (files are ordered **LilBlitz_01..06.png**) and the BBLITZZ logo from /brand.
4) Add your joke text (Inter/DM Sans). Keep text inside the dashed safe area.
5) Export PNG/WebP and post with #BBLITZZ #BlitzBison and mention @BBLITZZ.
